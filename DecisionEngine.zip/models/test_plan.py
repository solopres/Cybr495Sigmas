from typing import List
from .service import Service
from .test_module import TestModule


class TestPlan:
    def __init__(self, service: Service, tests: List[TestModule]):
        self.service = service
        self.tests = tests

    def __repr__(self):
        return f"TestPlan(service={self.service}, tests={self.tests})"