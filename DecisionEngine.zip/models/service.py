class Service:
    def __init__(self, name: str, port: int, protocol: str):
        self.name = name
        self.port = port
        self.protocol = protocol

    def __repr__(self):
        return f"Service(name={self.name}, port={self.port}, protocol={self.protocol})"