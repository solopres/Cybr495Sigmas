class RiskScore:
    def __init__(self, severity: str, confidence: float):
        self.severity = severity
        self.confidence = confidence

    def __repr__(self):
        return f"RiskScore(severity={self.severity}, confidence={self.confidence})"