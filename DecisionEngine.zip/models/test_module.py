from models.risk_score import RiskScore

class TestModule:
    def __init__(
        self,
        name,
        mitre_id,
        tactic,
        precondition,
        success_rate,
        effect,
        risk_score
    ):
        self.name = name
        self.mitre_id = mitre_id
        self.tactic = tactic
        self.precondition = precondition
        self.success_rate = success_rate
        self.effect = effect
        self.risk_score = risk_score

    def is_applicable(self, state):
        return self.precondition(state)

    def __repr__(self):
        return f"{self.name} ({self.mitre_id})"