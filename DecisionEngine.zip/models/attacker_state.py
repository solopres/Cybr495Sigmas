class AttackerState:
    def __init__(self):
        self.foothold = False
        self.access_level = "none"  # none, user, admin
        self.credentials = []
        self.discovered_hosts = []
        self.detected = False
        self.history = []

    def __repr__(self):
        return (
            f"AttackerState(foothold={self.foothold}, "
            f"access_level={self.access_level}, detected={self.detected})"
        )