from models.test_module import TestModule
from models.risk_score import RiskScore


def get_modules_for_service(service):
    modules = []

    if service.name.lower() == "http":
        modules.append(
            TestModule(
                name="Web Config Check",
                mitre_id="T1190",
                tactic="Initial Access",
                precondition=lambda s: not s.foothold,
                success_rate=0.6,
                effect=lambda s: setattr(s, "foothold", True),
                risk_score=RiskScore(severity="low", confidence=0.6)
            )
        )

    if service.name.lower() == "ssh":
        modules.append(
            TestModule(
                name="SSH Brute Force",
                mitre_id="T1110",
                tactic="Credential Access",
                precondition=lambda s: not s.foothold,
                success_rate=0.4,
                effect=lambda s: [
                    setattr(s, "foothold", True),
                    setattr(s, "access_level", "user")
                ],
                risk_score=RiskScore(severity="medium", confidence=0.4)
            )
        )

    return modules