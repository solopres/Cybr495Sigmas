import random
from typing import List
from models.service import Service
from models.test_plan import TestPlan
from models.attacker_state import AttackerState
from core.mapper import get_modules_for_service


class DecisionEngine:

    def __init__(self):
        self.state = AttackerState()

    def build_plan(self, services: List[Service]) -> List[TestPlan]:
        all_modules = []

        for service in services:
            modules = get_modules_for_service(service)
            all_modules.extend(modules)

        # FILTER based on state
        valid_modules = [
            m for m in all_modules if m.is_applicable(self.state)
        ]

        # SCORE them
        scored = [(m, self._score(m)) for m in valid_modules]

        # SORT by score
        scored.sort(key=lambda x: x[1], reverse=True)

        # Convert into execution plan
        plans = []
        for module, score in scored:
            plans.append(TestPlan(None, [module]))

        return plans

    def execute(self, module):
        success = random.random() < module.success_rate

        if success:
            module.effect(self.state)
            result = "SUCCESS"
        else:
            result = "FAIL"

        # FEEDBACK LOOP (ADD HERE)
        if result == "FAIL":
            self.state.detected = True  # optional

        self.state.history.append({
            "module": module.name,
            "tactic": module.tactic,
            "mitre": module.mitre_id,
            "result": result
        })

        return result

    def _score(self, module):
        base_severity = {
            "low": 1,
            "medium": 2,
            "high": 3
        }[module.risk_score.severity]

        confidence = module.risk_score.confidence

        score = base_severity * confidence

        # Dynamic adjustments based on state
        if self.state.detected:
            score *= 0.7  # attacker becomes more cautious

        if not self.state.foothold:
            if module.tactic == "Initial Access":
                score *= 1.5

        if self.state.access_level == "user":
            if module.tactic == "Privilege Escalation":
                score *= 2.0

        # History-based penalty (avoid repeating failures)
        failed_modules = [
            h["module"] for h in self.state.history if h["result"] == "FAIL"
        ]

        if module.name in failed_modules:
            score *= 0.5

        return score