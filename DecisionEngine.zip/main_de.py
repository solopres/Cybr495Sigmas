from decision_engine.decision_engine import DecisionEngine
from models.service import Service


def main():
    services = [
        Service("http", 80, "tcp"),
        Service("ssh", 22, "tcp"),
    ]

    engine = DecisionEngine()

    plans = engine.build_plan(services)

    for plan in plans:
        print(plan)

    # Execution phase
    for plan in plans:
        for module in plan.tests:

            if module.is_applicable(engine.state):
                result = engine.execute(module)

                print("\n--- CHOSEN ATTACK ---")
                print(f"Executed: {module.name} ({module.mitre_id})")
                print(f"Risk: {module.risk_score}")
                print(f"Result: {result}")
                print(f"State: {engine.state}")

if __name__ == "__main__":
    main()